import React, { useReducer } from "react";
import counterReducer from "./counterReducer";

const Counter = () => {
    const [state, dispatch] = useReducer(counterReducer, { count: 10 });

    return (
        <div style={{ textAlign: "center", padding: "20px" }}>
            <h2>Counter:{state.count}</h2>
            <button onClick={() => dispatch({ type: "INCREMENT" })}>+</button>
            <button onClick={() => dispatch({ type: "DECREMENT" })}>-</button>
            <button onClick={() => dispatch({ type: "RESET" })}>Reset</button>
        </div>
    )
}

export default Counter;



