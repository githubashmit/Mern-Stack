import {useState, useLayoutEffect} from "react"

export default function ChangeBackground(){
    const[color, setColor] = useState('aqua')

    useLayoutEffect(() =>{
        document.body.style.backgroundColor = color;
    },[color]);

    return(
        <div style={{textAlign:"center", padding:"20px"}}>
            <h2>Current Background:{color}</h2>
            <button onClick={() => setColor("red")}>Red</button>
            <button onClick={() => setColor("blue")}>Blue</button>
            <button onClick={() => setColor("yellow")}>Yellow</button>
        </div>
    )
}

