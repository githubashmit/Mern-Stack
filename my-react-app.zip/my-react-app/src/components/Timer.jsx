import { useState, useEffect } from "react";

const fmt = (ms) => {
    const total = Math.max(ms, 0)
    const s = Math.floor(total / 1000) % 60;
    const m = Math.floor(total / 60000);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default function Timer() {
    const [mode, setMode] = useState('up');
    const [running, setRunning] = useState(false);
    const [timeMs, setTimeMs] = useState(0);
    const [countdownMin, setCountdownMin] = useState(1);
    const intervalRef = useState(null);

    const toggleRun = () => setRunning((r) => !r)

    const reset = () => {
        setRunning(false);
        clearInterval(intervalRef.current);
        setTimeMs(mode == 'up' ? 0 : countdownMin * 6000);
    }

    const switchMode = () => {
        clearInterval(intervalRef.current);
        const next = mode === 'up' ? 'down' : 'up';
        setMode(next);
        setRunning(false);
        setTimeMs(next === 'up' ? 0 : countdownMin * 60000);
    }

    useEffect(() => {
        if (!running) return;
        intervalRef.current = setInterval(() => {
            setTimeMs((prev) => {
                if (mode === 'up') return prev + 1000;
                if (prev <= 1000) {
                    alert('Times Up!')
                    setRunning(false);
                    return 0;
                }
                return prev - 1000;
            })
        }, 1000);
        return () => clearInterval(intervalRef.current)
    }, [running, mode]);

    useEffect(() => {
        if (mode === 'down') setTimeMs(countdownMin * 6000);
    }, [countdownMin, mode])


    return (
        <div style={{ border: '2px solid #888', padding: 16 }}>
            <h3>{mode === 'up' ? 'Stopwatch' : 'Countdown'}</h3>

            <div style={{ fontSize: 40, textAlign: "center", margin: '8px 0' }}>
                {fmt(timeMs)}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
                <button onClick={toggleRun}>{running ? 'Pause' : 'Start'} </button>
                <button onClick={reset}>Reset</button>
                <button onClick={switchMode}>Switch Mode</button>
            </div>

            {mode === 'down' && !running && (
                <div style={{ marginTop: 10 }}>
                    <label>
                        Minutes:&nbsp
                        <input type="number" min="1" value={countdownMin} onChange={(e) => setCountdownMin(+e.target.value)}
                            style={{ width: 60 }}
                        />
                    </label>
                </div>
            )}

        </div>
    )
}

