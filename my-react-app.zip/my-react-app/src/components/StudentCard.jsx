import {useState} from 'react';

export default function StudentCard({name, grade}){
    const[quizzes, setQuizzes] =useState(0);
    return(
        <div style={{border: '1px solid #ccc',
            padding: '1rem',
        }}>
            <h3>{name}</h3>
            <p>Grade {grade}</p>

            {/* State */}
            <p>Quizzes Completed: {quizzes}</p>

            <button onClick={() => setQuizzes(quizzes + 1)}>
                Take a Quiz
            </button>
        </div>
    )
}