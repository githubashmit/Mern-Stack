import { useState } from 'react';

export default function Status() {
    const [status, setStatus] = useState('success')
    return (
        <div style={{ textAlign: "center", marginTop: 50 }}>
            <h2>Status Checker</h2>
            {
                status === 'loading' ? <p>⌚Loading...</p> :
                    status === 'success' ? <p>✅Loading...</p> :
                        status === 'error' ? <p>❌Loading...</p> :
                            <p>Idle</p>}

            <div style={{marginTop: 20}}>
                <button onClick={() => setStatus('loading')}>Set Loading</button>
                <button onClick={() => setStatus('success')}>Set Success</button>
                <button onClick={() => setStatus('error')}>Set Error</button>
                <button onClick={() => setStatus('idle')}>Set Idle</button>

            </div>
        </div>
    )
}