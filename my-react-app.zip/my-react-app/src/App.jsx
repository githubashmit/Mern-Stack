import React, {useState, useCallback} from "react";
import "./App.css"
import Button from "../hooks/useCallback"

const App =() =>{
    const[count, setCount] = useState(0);
    const[darkMode, setDarkMode] =useState(false);

    const handleClick = useCallback(() =>{
        setCount((prev) => prev+1);
    }, []);

    return(
        <div style={{background: darkMode?'#333':'#fff', color:darkMode ? '#fff':"000", paddding:'20px'}}>
            <h2>Count:{count}</h2>
            <Button onClick={handleClick}/>
            <button onClick={() => setDarkMode(!darkMode)}>Toggle Theme</button>
        </div>
    )
}

export default App;
